﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BarcodeLib;
using System.IO;
using System.Drawing.Imaging;


namespace Test1
{
    public partial class Form1 : Form
    {

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-S9B711P\\SQLEXPRESS;Initial Catalog=npb;User ID=sa;Password=sa@1234");
        public Form1()
        {
            InitializeComponent();
        }
        CheckBox HeaderCheckBox = null;
        CheckBox HeaderCheckBox1 = null;
        String s1;
        private void AddHeaderCheckBox()
        {
            HeaderCheckBox = new CheckBox();
            HeaderCheckBox.Size = new Size(15, 15);
            this.dataGridView1.Controls.Add(HeaderCheckBox);
            
        }

        private void AddHeaderCheckBox1()
        {
            HeaderCheckBox1 = new CheckBox();
            HeaderCheckBox1.Size = new Size(15, 15);
            this.dataGridView2.Controls.Add(HeaderCheckBox1);

        }
        //Click Event
        private void HeaderCheckBoxClick(CheckBox HCheckBox)
        {
            foreach (DataGridViewRow Row in dataGridView1.Rows)
                ((DataGridViewCheckBoxCell)Row.Cells["Column1"]).Value = HCheckBox.Checked;
          
            dataGridView1.RefreshEdit();   
        }

        private void HeaderCheckBox1Click(CheckBox HCheckBox1)
        {
            foreach (DataGridViewRow Row in dataGridView2.Rows)
                ((DataGridViewCheckBoxCell)Row.Cells["Column4"]).Value = HCheckBox1.Checked;

            dataGridView2.RefreshEdit();
        }
        //mouse click event
        private void HeaderCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            HeaderCheckBoxClick((CheckBox)sender);
        }

        private void HeaderCheckBox1_MouseClick(object sender, MouseEventArgs e)
        {
            HeaderCheckBox1Click((CheckBox)sender);
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            s1 = comboBox1.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            display_data();
        }
        public void display_data()
        {
            con.Open();
            if (s1 == "All")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select Shop_name,Shop_ID from tbl_ShopMaster", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.Rows.Clear();
                foreach (DataRow item in dt.Rows)
                {                 
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells[0].Value = false;
                    dataGridView1.Rows[n].Cells[2].Value = item["Shop_Name"].ToString();
                    dataGridView1.Rows[n].Cells[3].Value = item["Shop_ID"].ToString();
                }
            }
         
            if (s1 == "Franchise")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select Shop_name,Shop_ID from tbl_ShopMaster where ShopType_ID = 1", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.Rows.Clear();
               
                foreach (DataRow item in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells[0].Value = false;
                    dataGridView1.Rows[n].Cells[2].Value = item["Shop_Name"].ToString();
                    dataGridView1.Rows[n].Cells[3].Value = item["Shop_ID"].ToString();
                }
            }
            
            if (s1 == "Non Franchise")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select Shop_name,Shop_ID from tbl_ShopMaster where ShopType_ID = 2", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.Rows.Clear();
                foreach (DataRow item in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells[0].Value = false;
                    dataGridView1.Rows[n].Cells[2].Value = item["Shop_Name"].ToString();
                    dataGridView1.Rows[n].Cells[3].Value = item["Shop_ID"].ToString();

                }
            }
  
            if (s1 == "Distributor")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select Shop_name,Shop_ID from tbl_ShopMaster where ShopType_ID = 3", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.Rows.Clear();
                foreach (DataRow item in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells[0].Value = false;
                    dataGridView1.Rows[n].Cells[2].Value = item["Shop_Name"].ToString();
                    dataGridView1.Rows[n].Cells[3].Value = item["Shop_ID"].ToString();

                }
            }
            
            if (s1 == "Distributor1")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select Shop_name,Shop_ID from tbl_ShopMaster where ShopType_ID = 4", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.Rows.Clear();
                foreach (DataRow item in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add(); 
                    dataGridView1.Rows[n].Cells[0].Value = false;
                    dataGridView1.Rows[n].Cells[2].Value = item["Shop_Name"].ToString();
                    dataGridView1.Rows[n].Cells[3].Value = item["Shop_ID"].ToString();
                }
            }
            con.Close();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;   
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'npbDataSet.tbl_ShopTypeMaster' table. You can move, or remove it, as needed.
            
            AddHeaderCheckBox();// Button
            HeaderCheckBox.MouseClick += new MouseEventHandler(HeaderCheckBox_MouseClick);

            AddHeaderCheckBox1();// Button
            HeaderCheckBox1.MouseClick += new MouseEventHandler(HeaderCheckBox1_MouseClick);


            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            //Set preferred index to show as default value
            comboBox1.SelectedIndex = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {    
        }
       
        private void button3_Click(object sender, EventArgs e)      
        {
            display_data2();  
        }

        public void display_data2()
        {
            dataGridView2.Rows.Clear();
            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                if ((bool)item.Cells[0].Value == true)
                {
                    string str = item.Cells[3].Value.ToString();
                    SqlDataAdapter sda = new SqlDataAdapter("SELECT Invoice_Number,Invoice_ID From tbl_Invoice,tbl_InvoiceItem where Shop_ID  = '" + str + "' and tbl_Invoice.ID = tbl_InvoiceItem.Invoice_ID and InvoiceDateTime between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' And '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    foreach (DataRow data in dt.Rows)
                    {
                        int m = dataGridView2.Rows.Add();
                        dataGridView2.Rows[m].Cells[0].Value = false;
                        dataGridView2.Rows[m].Cells[2].Value = data["Invoice_Number"].ToString();
                        dataGridView2.Rows[m].Cells[3].Value = data["Invoice_ID"].ToString();
                    }
                }
            }
        }
        
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }
        private void label11_Click(object sender, EventArgs e)
        {
        }
        private void label7_Click(object sender, EventArgs e)
        {
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        public void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if((bool)dataGridView1.SelectedRows[0].Cells[0].Value == false)
            {
                dataGridView1.SelectedRows[0].Cells[0].Value = true;
            }
            else
            {
                dataGridView1.SelectedRows[0].Cells[0].Value = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            a0.Visible = true;
            p0.Visible = true;
            a5.Visible = true;
            p5.Visible = true;
            a12.Visible = true;
            p12.Visible = true;
            a18.Visible = true;
            p18.Visible = true;
            label4.Visible = true;
            label13.Visible = true;
            label11.Visible = true;
            label10.Visible = true;
            label9.Visible = true;
            label8.Visible = true;
            label7.Visible = true;
            label6.Visible = true;
            display_data3();

        }

        public void display_data3()
        {
            dataGridView3.Rows.Clear();
            foreach (DataGridViewRow val in dataGridView2.Rows)
            {
                if ((bool)val.Cells[0].Value == true)
                {
                    string arr = val.Cells[3].Value.ToString();
                    SqlDataAdapter sda = new SqlDataAdapter("exec sp_ReadInvoice_ForAdjust '"+arr+"',0,0,0,0,0", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    foreach (DataRow data in dt.Rows)
                    {
                        int m = dataGridView3.Rows.Add();
                        dataGridView3.Rows[m].Cells[2].Value = data["InvoiceID"].ToString();
                        dataGridView3.Rows[m].Cells[3].Value = data["Inv Number"].ToString();
                        dataGridView3.Rows[m].Cells[4].Value = data["Inv Date"].ToString();
                        dataGridView3.Rows[m].Cells[5].Value = data["ShopName"].ToString();
                        dataGridView3.Rows[m].Cells[6].Value = data["Taxable Amt"].ToString();
                        dataGridView3.Rows[m].Cells[7].Value =data["Inv Amt"].ToString();
                        dataGridView3.Rows[m].Cells[8].Value = Convert.ToDouble(data["Tax 0 Amt"].ToString());
                        dataGridView3.Rows[m].Cells[9].Value = Convert.ToDouble(data["0 Percent"].ToString());
                        dataGridView3.Rows[m].Cells[10].Value = Convert.ToDouble(data["Tax 5 Amt"].ToString());
                        dataGridView3.Rows[m].Cells[11].Value = Convert.ToDouble(data["5 Percent"].ToString());
                        dataGridView3.Rows[m].Cells[12].Value = Convert.ToDouble(data["Tax 12 Amt"].ToString());
                        dataGridView3.Rows[m].Cells[13].Value = Convert.ToDouble(data["12 Percent"].ToString());
                        dataGridView3.Rows[m].Cells[14].Value = Convert.ToDouble(data["Tax 18 Amt"].ToString());
                        dataGridView3.Rows[m].Cells[15].Value = Convert.ToDouble(data["18 Percent"].ToString());
                        Double x = 0;
                        Double p = 0;
                        Double q = 0;
                        Double r = 0;
                        Double s = 0;
                        Double t = 0;
                        Double u = 0;
                        Double v = 0;

                        foreach (DataGridViewRow fk in dataGridView3.Rows)
                        { 
                            Double  a = (Double)fk.Cells[8].Value;
                              x = x + a;

                            Double b = (Double)fk.Cells[9].Value;
                            p = p + b;

                            Double c = (Double)fk.Cells[10].Value;
                            q = q + c;

                            Double d = (Double)fk.Cells[11].Value;
                            r = r + d;

                            Double e = (Double)fk.Cells[12].Value;
                            s = s + e;

                            Double f = (Double)fk.Cells[13].Value;
                            t = t + f;

                            Double g = (Double)fk.Cells[14].Value;
                            u= u + g;

                            Double h = (Double)fk.Cells[15].Value;
                            v = v + h;
                        }
                        label4.Text = x.ToString();
                        label13.Text = p.ToString();
                        label11.Text = q.ToString();
                        label10.Text = r.ToString();
                        label9.Text = s.ToString();
                        label8.Text = t.ToString();
                        label7.Text = u.ToString();
                        label6.Text = v.ToString();   
                    }
                }
            }
        }
        private void dataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            this.dataGridView1.Rows[e.RowIndex].Cells["sno"].Value = (e.RowIndex + 1).ToString();
        }

        private void dataGridView2_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            this.dataGridView2.Rows[e.RowIndex].Cells["Column5"].Value = (e.RowIndex + 1).ToString();
        }

        private void dataGridView3_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            this.dataGridView3.Rows[e.RowIndex].Cells["Column3"].Value = (e.RowIndex + 1).ToString();
        }

        private void dataGridView2_MouseClick(object sender, MouseEventArgs e)
        {
            if((bool)dataGridView2.SelectedRows[0].Cells[0].Value == false)
            {
                dataGridView2.SelectedRows[0].Cells[0].Value = true;
            }
            else
            {
                dataGridView2.SelectedRows[0].Cells[0].Value = false;
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void label4_Click_1(object sender, EventArgs e)
        {
        }

        private void dataGridView3_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            //foreach (DataGridViewRow val in dataGridView3.Rows)
            //{
              // string s = val.Cells[2].Value.ToString();
               // MessageBox.Show(s);
 //               Barcode barcode = new Barcode();
   //             Color f = Color.Black;
     //           Color B = Color.Transparent;
       //         Image img = barcode.Encode(TYPE.CODE128, s, f, B, (int)(pictureBox1.Width * 0.8), (int)(pictureBox1.Height * 0.8));
         //       pictureBox1.Image = img;
           // }
         }

        private void button6_Click(object sender, EventArgs e)
        {
           // using (SaveFileDialog saveFileDialog = new SaveFileDialog() { Filter = "PNG|*.png*" })
            //{
              //  if (pictureBox1 == null)
                //    return;
         //       if(saveFileDialog.ShowDialog()==DialogResult.OK)
           //     {
             //       pictureBox1.Image.Save(saveFileDialog.FileName);
       //         }
         //   }
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
